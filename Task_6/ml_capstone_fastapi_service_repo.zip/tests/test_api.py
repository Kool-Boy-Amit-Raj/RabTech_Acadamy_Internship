import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["model_loaded"] is True

def test_predict_valid_payload():
    payload = {
        "age": 32,
        "annual_income": 800000.0,
        "credit_score": 740.0,
        "debt_to_income_ratio": 0.22,
        "open_credit_lines": 3,
        "home_ownership": "OWN",
        "loan_purpose": "HOME_IMPROVEMENT",
        "employment_type": "SALARIED"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "prediction_label" in data
    assert "default_probability" in data
    assert "risk_level" in data
    assert isinstance(data["default_probability"], float)
    assert 0.0 <= data["default_probability"] <= 1.0

def test_predict_high_risk_payload():
    payload = {
        "age": 24,
        "annual_income": 220000.0,
        "credit_score": 520.0,
        "debt_to_income_ratio": 0.62,
        "open_credit_lines": 8,
        "home_ownership": "RENT",
        "loan_purpose": "BUSINESS",
        "employment_type": "UNEMPLOYED"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["prediction_label"] == 1
    assert data["default_probability"] > 0.50
    assert data["risk_level"] in ["MEDIUM", "HIGH"]

def test_predict_invalid_schema():
    # Missing required fields and invalid credit score (< 300)
    invalid_payload = {
        "age": 15,
        "credit_score": 150.0
    }
    response = client.post("/predict", json=invalid_payload)
    assert response.status_code == 422  # Unprocessable Entity
