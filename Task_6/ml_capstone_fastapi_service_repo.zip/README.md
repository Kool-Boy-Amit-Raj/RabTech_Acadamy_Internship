# Real-Time ML Inference REST API & Capstone Architecture

A production-ready, containerized microservice built with **FastAPI**, **Docker**, and **Scikit-Learn** for real-time Credit Default Risk assessment.

---

## 1. System Architecture Overview

```
                 +-------------------------------------------------+
                 |                Client Applications              |
                 +-------------------------------------------------+
                                          |
                                    HTTP POST (JSON)
                                          v
+-----------------------------------------------------------------------------------+
| Docker Container (Port 8000)                                                      |
|                                                                                   |
|   +-----------------------+     +-----------------------+     +-----------------+ |
|   |   FastAPI / Uvicorn   | --> | Pydantic Request Val. | --> | Pipeline Engine | |
|   |  - GET  /             |     |  - Type checking      |     |  - RobustScaler | |
|   |  - POST /predict      |     |  - Range boundaries   |     |  - SimpleImpute | |
|   |  - POST /predict/batch|     |  - Missingness handle |     |  - OneHotEncode | |
|   +-----------------------+     +-----------------------+     +-----------------+ |
|                                                                        |          |
|                                                                        v          |
|                                                               +-----------------+ |
|                                                               | Champion Model  | |
|                                                               | (Logistic / RF) | |
|                                                               +-----------------+ |
+-----------------------------------------------------------------------------------+
```

---

## 2. API Endpoints Specification

### `GET /`
Service healthcheck endpoint.
* **Response `200 OK`**:
```json
{
  "status": "healthy",
  "service": "Real-Time ML Inference REST API",
  "model_loaded": true,
  "version": "1.0.0"
}
```

### `POST /predict`
Processes a single loan applicant payload and generates calibrated risk probabilities.
* **Sample Request Body:**
```json
{
  "age": 35,
  "annual_income": 750000.0,
  "credit_score": 710.0,
  "debt_to_income_ratio": 0.28,
  "open_credit_lines": 4,
  "home_ownership": "RENT",
  "loan_purpose": "DEBT_CONSOLIDATION",
  "employment_type": "SALARIED"
}
```
* **Sample Response `200 OK`:**
```json
{
  "prediction_label": 0,
  "prediction_status": "Non-Default",
  "default_probability": 0.2854,
  "risk_level": "LOW"
}
```

### `POST /predict/batch`
Batch inference endpoint accepting multiple applicant records in one roundtrip.

---

## 3. Local Development & Testing

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Test Suite
```bash
pytest tests/test_api.py -v
```

### 3. Launch Local Server
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive Swagger UI documentation is available at `http://localhost:8000/docs`.

---

## 4. Docker Build & Deployment

### 1. Build the Docker Image
```bash
docker build -t ml-inference-capstone:1.0.0 .
```

### 2. Run Container
```bash
docker run -d -p 8000:8000 --name ml-inference-service ml-inference-capstone:1.0.0
```

### 3. Verify Container Status
```bash
curl http://localhost:8000/
```
