import os
import joblib
import pandas as pd
from typing import List, Literal, Optional
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field

app = FastAPI(
    title="Real-Time ML Inference REST API",
    version="1.0.0",
    description="Production-grade inference service for Credit Default Risk evaluation using serialized Champion Scikit-Learn Pipeline."
)

MODEL_PATH = os.getenv("MODEL_PATH", "model/champion_model.joblib")

# Load model pipeline on startup
try:
    model_pipeline = joblib.load(MODEL_PATH)
    print(f"Successfully loaded model pipeline from {MODEL_PATH}")
except Exception as e:
    print(f"Error loading model from {MODEL_PATH}: {e}")
    model_pipeline = None

class LoanApplicant(BaseModel):
    age: int = Field(..., ge=18, le=100, example=35)
    annual_income: float = Field(..., ge=0.0, example=750000.0)
    credit_score: float = Field(..., ge=300.0, le=850.0, example=710.0)
    debt_to_income_ratio: float = Field(..., ge=0.0, le=1.5, example=0.28)
    open_credit_lines: int = Field(..., ge=0, example=4)
    home_ownership: Literal["RENT", "OWN", "MORTGAGE"] = Field(..., example="RENT")
    loan_purpose: Literal["DEBT_CONSOLIDATION", "HOME_IMPROVEMENT", "BUSINESS", "EDUCATION", "PERSONAL"] = Field(..., example="DEBT_CONSOLIDATION")
    employment_type: Optional[Literal["SALARIED", "SELF_EMPLOYED", "FREELANCE", "UNEMPLOYED"]] = Field(None, example="SALARIED")

class BatchPredictionRequest(BaseModel):
    applicants: List[LoanApplicant]

class SinglePredictionResponse(BaseModel):
    prediction_label: int = Field(..., description="1 for Default, 0 for Non-Default")
    prediction_status: str
    default_probability: float = Field(..., description="Estimated probability of default")
    risk_level: str

class BatchPredictionResponse(BaseModel):
    total_records: int
    predictions: List[SinglePredictionResponse]

@app.get("/", tags=["Health"])
def root_health():
    return {
        "status": "healthy",
        "service": "Real-Time ML Inference REST API",
        "model_loaded": model_pipeline is not None,
        "version": "1.0.0"
    }

@app.post("/predict", response_model=SinglePredictionResponse, status_code=status.HTTP_200_OK, tags=["Inference"])
def predict_single(applicant: LoanApplicant):
    if model_pipeline is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model artifact is not loaded or missing."
        )
    
    input_df = pd.DataFrame([applicant.model_dump()])
    
    try:
        prob = float(model_pipeline.predict_proba(input_df)[0, 1])
        pred = int(prob >= 0.50)
        
        risk = "HIGH" if prob >= 0.70 else ("MEDIUM" if prob >= 0.40 else "LOW")
        
        return SinglePredictionResponse(
            prediction_label=pred,
            prediction_status="Default" if pred == 1 else "Non-Default",
            default_probability=round(prob, 4),
            risk_level=risk
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference error during model execution: {str(e)}"
        )

@app.post("/predict/batch", response_model=BatchPredictionResponse, status_code=status.HTTP_200_OK, tags=["Inference"])
def predict_batch(payload: BatchPredictionRequest):
    if model_pipeline is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model artifact is not loaded or missing."
        )
    
    if not payload.applicants:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Applicant payload cannot be empty."
        )
        
    records = [app.model_dump() for app in payload.applicants]
    input_df = pd.DataFrame(records)
    
    try:
        probs = model_pipeline.predict_proba(input_df)[:, 1]
        preds = (probs >= 0.50).astype(int)
        
        results = []
        for p, pr in zip(preds, probs):
            p_float = float(pr)
            results.append(SinglePredictionResponse(
                prediction_label=int(p),
                prediction_status="Default" if p == 1 else "Non-Default",
                default_probability=round(p_float, 4),
                risk_level="HIGH" if p_float >= 0.70 else ("MEDIUM" if p_float >= 0.40 else "LOW")
            ))
            
        return BatchPredictionResponse(
            total_records=len(results),
            predictions=results
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch inference error: {str(e)}"
        )
